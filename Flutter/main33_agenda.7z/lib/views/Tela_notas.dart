import 'package:flutter/material.dart';
import 'package:agenda/models/exports.dart';

class TelaNotas extends StatefulWidget {
  @override
  _TelaNotasState createState() => _TelaNotasState();
}

class _TelaNotasState extends State<TelaNotas> {
  //
  final notas = Nota();

  //Para IOS
  late ScrollController scrollController;

  @override
  void initState() {
    super.initState();
    scrollController = ScrollController()
      ..addListener(() {
        FocusScope.of(context).requestFocus(FocusNode());
      });
  }

  @override
  // Desmonta um objeto State
  // Este método de limpeza é chamado quando o objeto de estado é removido
  // da árvore de widgets. Esta é sua última oportunidade de limpar todos 
  // os recursos que precisam ser liberados explicitamente.
  void dispose() {
    scrollController.dispose();
    super.dispose();
  }

@override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Minha Agenda'),
        backgroundColor: Colors.blueGrey,
      ),
      //
      body: _buildList(),
      floatingActionButton: _buildAddTaskButton(),
    );
  }

 Widget _buildAddTaskButton() {
    return FloatingActionButton(
      child: Icon(Icons.add),
      onPressed: () {
        setState(() {
          //clicar no borão + cria uma tarefa
          notas.tarefas.add(Tarefa());
        });
      },
    );
  }

  Widget _buildList() {
    return ListView.builder(
      itemCount: notas.tarefas.length,
      itemBuilder: (contex, indice) => _buildTaskTile(notas.tarefas[indice]),      
    );
  }

    Widget _buildTaskTile(Tarefa tarefas) {
    return ListTile(
      leading: Checkbox(
          value: tarefas.completa,
          onChanged: (selecionado) {
            setState(() {
              tarefas.completa = selecionado!;
            });
          }),
      title: TextField(
        onChanged: (text) {
          setState(() {
            tarefas.descricao = text;
          });
        },
      ),
    );
  }
}