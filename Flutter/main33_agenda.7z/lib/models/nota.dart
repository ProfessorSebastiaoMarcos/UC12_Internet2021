import 'package:agenda/models/tarefa.dart';

class Nota {
  String nome = '';
  final List<Tarefa> tarefas = [];
}
