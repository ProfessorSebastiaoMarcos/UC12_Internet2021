class Tarefa {
  String descricao;
  bool completa;

  //construtor
  Tarefa({
    this.completa = false,
    this.descricao = ''
  });
}
